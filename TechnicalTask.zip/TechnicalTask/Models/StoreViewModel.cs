﻿namespace TechnicalTask.Models
{
    public class StoreViewModel
    {
    }
}
